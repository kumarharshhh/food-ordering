
import React, { useState } from 'react';

const foodItems = [
  { id: 1, name: 'Pizza', price: 250, image: 'https://i.imgur.com/eTmWoAN.png' },
  { id: 2, name: 'Burger', price: 150, image: 'https://i.imgur.com/5cX1YFG.png' },
  { id: 3, name: 'Pasta', price: 200, image: 'https://i.imgur.com/HK3IVzj.png' }
];

function Home() {
  const [cart, setCart] = useState([]);

  const addToCart = (item) => {
    const updatedCart = [...cart, item];
    setCart(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  return (
    <div style={{ padding: '1rem' }}>
      <h2>Menu</h2>
      <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
        {foodItems.map(item => (
          <div key={item.id} style={{ border: '1px solid #ccc', padding: '1rem', width: '200px' }}>
            <img src={item.image} alt={item.name} style={{ width: '100%', height: 'auto' }} />
            <h3>{item.name}</h3>
            <p>₹{item.price}</p>
            <button onClick={() => addToCart(item)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;
